BSD-3-Clause License
====================

.. literalinclude:::: ../LICENSE.txt
    :language: text
