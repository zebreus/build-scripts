::: typing_inspection.introspection
    options:
      show_labels: false
      group_by_category: false
      members:
        - is_union_origin
        - get_literal_values
        - inspect_annotation
        - AnnotationSource
        - Qualifier
        - InspectedAnnotation
        - UNKNOWN
        - ForbiddenQualifier
