Geometry properties
===================

.. currentmodule:: shapely

.. autosummary::
   :toctree: reference/

{% for function in get_module_functions("_geometry") %}
   {{ function }}
{% endfor %}
