Predicates
==========

.. currentmodule:: shapely

.. autosummary::
   :toctree: reference/

{% for function in get_module_functions("predicates") %}
   {{ function }}
{% endfor %}
