Plotting
========

.. currentmodule:: shapely

.. autosummary::
   :toctree: reference/

   plotting.patch_from_polygon
   plotting.plot_polygon
   plotting.plot_line
   plotting.plot_points
