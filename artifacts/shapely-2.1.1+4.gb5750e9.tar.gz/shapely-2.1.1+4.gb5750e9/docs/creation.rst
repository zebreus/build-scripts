.. _ref-creation:

Geometry creation
=================

.. currentmodule:: shapely

.. autosummary::
   :toctree: reference/

{% for function in get_module_functions("creation") %}
   {{ function }}
{% endfor %}
